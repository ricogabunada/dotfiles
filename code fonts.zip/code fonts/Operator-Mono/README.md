
# Operator-Mono Font

A nice code font

## Usage

```sh
$ git clone https://github.com/keyding/Operator-Mono.git
```




